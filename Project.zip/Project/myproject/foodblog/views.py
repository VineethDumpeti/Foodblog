from django.shortcuts import render, get_object_or_404
from .models import Food
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

def food_list(request):
    object_list = Food.objects.all()

    paginator = Paginator(object_list, 3)
    page = request.GET.get('page')
    try:
        foods = paginator.page(page)
    except PageNotAnInteger:
        foods = paginator.page(1)
    except EmptyPage:
        foods = paginator.page(paginator.num_pages)


    return render(
        request,
        'foodblog/food/list.html',
        {'foods' : foods }
    )

def food_detail(request,year,month,day,food):
    food = get_object_or_404(
        Food,
        slug=food,
        status='published',
        publish__year=year,
        publish__month=month,
        publish__day=day
        )
    return render(
        request,
        'foodblog/food/detail.html',
        {'food' : food}
    )
